#include "grib_api_internal.h"

const char * grib_get_git_sha1() { return "ffaa809f0bd302591e62a479db7bddfb05a4ba59"; }
